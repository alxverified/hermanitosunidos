import json
from pyrogram import Client, filters

@Client.on_message(filters.command("und", ["/", "."]))
async def undowngrade_user(client, message):
    user_id = str(message.from_user.id)
    args = message.command[1:]
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as user_file:
        users = json.load(user_file)
        admin = next((u for u in users if u['id'] == user_id), None)
        if not admin or admin['plan'] not in ['Seller', 'Owner']:
            await message.reply("<b>❌ No tienes permiso para usar este comando.</b>")
            return
    if len(args) < 1:
        await message.reply("<b>❌ Especifica el ID del usuario que deseas degradar a Free User.</b>")
        return
    target_id = args[0]
    with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as user_file:
        users = json.load(user_file)
        user = next((u for u in users if u['id'] == target_id), None)
        if not user:
            await message.reply("<b>Usuario no encontrado.</b>")
            return
        if user['plan'] in ['Seller', 'Owner']:
            await message.reply("<b>El usuario tiene un plan especial. Usa otro comando específico para esto.</b>")
            return
        user['plan'] = 'Free User'
        user['dias'] = '0'
        user['creditos'] = '0'
        user_file.seek(0)
        json.dump(users, user_file, indent=4)
        user_file.truncate()
        await message.reply(f"<b>✔ User: {target_id} has been promoted to Free User. </b>")