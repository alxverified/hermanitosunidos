import requests
import json
from pyrogram import Client, filters
from pyrogram.types import Message

BIN_API_URL = "https://anthony086.alwaysdata.net/index.php?bin={bin}"
USERS_PATH = "comandos/usuarios/users.json"

def is_user_registered(user_id):
    with open(USERS_PATH, "r") as f:
        users = json.load(f)
        return any(user['id'] == str(user_id) for user in users)

@Client.on_message(filters.command("bin", prefixes=["/", ".", "!"]))
async def check_bin(client: Client, message: Message):
    if not is_user_registered(message.from_user.id):
        await message.reply("Debes registrarte usando el comando <code>/register</code> antes de usar este comando. 🎈", reply_to_message_id=message.id)
        return

    command_parts = message.text.split()
    
    if len(command_parts) != 2:
        await message.reply("——————————————\n⌇ **COMANDO** /bin | **[伊祖-CHK]**  \n⌇ **EJEMPLO** ⇸  <code>/bin 455599</code> \n⌇ **TOOL** ⇸ **Bin Finder** \n——————————————", reply_to_message_id=message.id)
        return
    
    bin_number = command_parts[1]
    response = requests.get(BIN_API_URL.format(bin=bin_number))
    
    if response.status_code != 200:
        await message.reply("**Error al conectar con la API.** ❌", reply_to_message_id=message.id)
        return
    
    data = response.json()
    
    if not data.get("status"):
        await message.reply("**El BIN proporcionado no es válido.** ❌", reply_to_message_id=message.id)
        return
    
    info = data['info']
    reply_message = (
        f"——————————————\n"
        f"**BIN**: <code>**{info['bin']}**</code>\n"
        f"**BANCO**: <code>**{info['bank']}**</code> \n"
        f"**PAIS**: <code>**{info['country']}**</code> - <code>**{info['flag']}**</code>\n"
        "——————————————\n"
        f"**INFO**: <code>**{info['brand']}**</code> <code>**{info['type']}**</code> <code>**{info['level']}**</code>\n"
        f"**BOT BY**: @ElTripleA\n"
        f"**RQ BY**: @{message.from_user.username}"
    )
    
    await message.reply(reply_message, reply_to_message_id=message.id)
