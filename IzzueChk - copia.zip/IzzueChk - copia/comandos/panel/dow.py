import random
import json
from datetime import datetime
from pyrogram import Client, filters, enums
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant
from datetime import datetime
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

@Client.on_message(filters.command("dow", ["/", "."]))
async def remove_owner(client, message):
    user_to_remove = message.command[1] if len(message.command) > 1 else None
    if not user_to_remove:
        await message.reply("<b>Especifica un usuario para quitar el rol de Owner.</b>")
        return
    original_owner = "5616163365"
    if user_to_remove == original_owner:
        await message.reply(f"<b>No puedes quitar el rol de Owner al Creador Supremo: ({original_owner}).</b>")
        return
    with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as user_file:
        users = json.load(user_file)
        for user in users:
            if user["id"] == user_to_remove and user["plan"] == "Owner":
                user["plan"] = "Free User"
                user_file.seek(0)
                json.dump(users, user_file, indent=4)
                await message.reply(f"<b>Rol de Owner removido para el usuario {user_to_remove}.</b>")
                return
        await message.reply("<b>Usuario no encontrado o no es Owner.</b>")
