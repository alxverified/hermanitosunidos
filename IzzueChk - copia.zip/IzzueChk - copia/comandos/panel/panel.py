import json
from pyrogram import Client, filters

@Client.on_message(filters.command("panel", ["/", "."]))
async def show_panel(client, message):
    user_id = str(message.from_user.id)
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)
        user = next((user for user in users if user['id'] == user_id), None)
    if user and user['plan'] in ['Seller', 'Owner']:
        panel_message = (
            "🏴‍☠️ Lista de Comandos 🏴‍☠️\n"
            "━━━━━━✧❂✧━━━━━━\n"
            "/dkey - Elimina una key. ( Seller y Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/dlog - Elimina carpetas PYCache ( Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/dow - Elimina Rank Owner. ( Creador )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/key - Generar key. ( Seller, Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/ow - Dar Owner. ( Creador )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/rs - Reset Server. ( Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/seller - Dar rango Seller. ( Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/und - Quitar Rango Premium. ( Seller, Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/addc - Añadir Creditos. ( Seller, Owner )\n"
            "━━━━━━✧♛✧━━━━━━\n"
            "/removec - Restar Creditos. ( Seller, Owner )"
        )
        await message.reply(panel_message)
