import json
from pyrogram import Client, filters

CHAT_ID = -1002473488514

@Client.on_message(filters.command("dkey", ["/", "."]))
async def delete_key(client, message):
    user_id = str(message.from_user.id)
    key_to_delete = message.command[1] if len(message.command) > 1 else None
    
    if not key_to_delete:
        await message.reply("<b>Especifica una key para eliminar.</b>")
        return
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as user_file:
        users = json.load(user_file)
        user = next((u for u in users if u['id'] == user_id), None)
        
    if not user or user['plan'] not in ['Seller', 'Owner']:
        await message.reply("<b>No tienes permiso para eliminar keys.</b>")
        return
    with open('comandos/logs/keys_log.json', 'r+', encoding='utf-8') as log_file:
        logs = json.load(log_file)
        found = False
        for uid, keys in logs.items():
            updated_keys = [key for key in keys if key["key"] != key_to_delete]
            if len(updated_keys) < len(keys):
                found = True
                logs[uid] = updated_keys
        if found:
            log_file.seek(0)
            json.dump(logs, log_file, indent=4)
            log_file.truncate()  # Ensure no extra content remains
            await message.reply(f"<b>Key {key_to_delete} eliminada.</b>")
            try:
                plan = user['plan']
                username = message.from_user.username if message.from_user.username else "SinUsername"
                notification_message = (f"♻ El **{plan}** - **{username}** \n 🗣 Eliminó la key: <code>{key_to_delete}</code>")
                await client.send_message(CHAT_ID, notification_message)
            except Exception as e:
                await message.reply(f"<b>Error al enviar la notificación: {e}</b>")
            
        else:
            await message.reply(f"<b>Key {key_to_delete} no encontrada.</b>")
