import json
from pyrogram import Client, filters

@Client.on_message(filters.command("seller", ["/", "."]))
async def give_seller(client, message):
    user_to_give = message.command[1] if len(message.command) > 1 else None
    if not user_to_give:
        await message.reply("<b>Indica el ID para asignar el rol de Seller. Uso: /seller <id></b>")
        return
    sender_id = str(message.from_user.id)
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as user_file:
        users = json.load(user_file)
        sender_user = next((user for user in users if user["id"] == sender_id), None)
        if sender_user is None or sender_user["plan"] != "Owner":
            await message.reply("<b>No tienes permisos para usar este comando. ❌ </b>")
            return
        user_to_promote = next((user for user in users if user["id"] == user_to_give), None)
        if user_to_promote:
            user_to_promote["plan"] = "Seller"
            with open('comandos/usuarios/users.json', 'w', encoding='utf-8') as user_file:
                json.dump(users, user_file, indent=4)
            await message.reply(f"<b>El Usuario {user_to_give} ahora es Seller. 🐱‍👤</b>")
        else:
            await message.reply("<b>Usuario no encontrado. Asegúrate de que el Usuario esté registrado en el bot. 👻</b>")
