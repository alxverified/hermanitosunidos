import json
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

@Client.on_message(filters.command(["me", "info", "perfil"], ["/", "."]))
async def user_info(client, message):
    user_id = str(message.from_user.id)
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)
        user = next((user for user in users if user['id'] == user_id), None)
    if not user:
        await message.reply("<b>❌ El usuario no está registrado.</b>")
        return
    username = user['username'].replace('@', '')
    plan = user['plan']
    creditos = user['creditos']
    dias = int(user['dias'])
    key_status = "<code>No Key Actived</code>" if dias <= 0 else f"<code>Key Actived</code> - <code>{dias}</code> días"
    response_message = (
        f"⌇ **USUARIO** | <code>{username} - {user_id}</code> [<code>{creditos}</code> créditos]\n"
        f"⌇ **STATUS** | <code>{plan}</code>\n"
        f"⌇ **KEY** | {key_status}"
    )
    if message.command[0] in ["me"]:
        header = "**ABOUT YOU** | [ **伊祖-CHK** ]"
    elif message.command[0] in ["info"]:
        header = "**INFO** | [ **伊祖-CHK** ]"
    else:
        header = "**PERFIL** | [ **伊祖-CHK** ]"
    full_message = f"{header}\n{response_message}"
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("𝙲𝚊𝚗𝚊𝚕 𝙾𝚏𝚒𝚌𝚒𝚊𝚕", url="https://t.me/federalizados")]
    ])

    try:
        profile_photos = await client.get_profile_photos(user_id)
        if profile_photos:
            await client.send_photo(
                chat_id=message.chat.id,
                photo=profile_photos[0].file_id,
                caption=full_message,
                reply_markup=keyboard
            )
        else:
            await message.reply(full_message, reply_markup=keyboard)
    except Exception:
        await message.reply(full_message, reply_markup=keyboard)