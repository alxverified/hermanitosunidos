import json
from datetime import datetime

users_file = 'comandos/usuarios/users.json'

def reducir_dias():
    with open(users_file, 'r+', encoding='utf-8') as archivo_usuarios:
        usuarios = json.load(archivo_usuarios)

        for usuario in usuarios:
            if usuario['plan'] == 'Premium':
                dias = int(usuario.get('dias', 0)) 
                if dias > 0:
                    usuario['dias'] = str(dias - 1)
                if dias - 1 <= 0:
                    usuario['plan'] = 'Free User'
                    usuario['dias'] = '0'
        archivo_usuarios.seek(0)
        json.dump(usuarios, archivo_usuarios, indent=4)
        archivo_usuarios.truncate()
if __name__ == "__main__":
    reducir_dias()
