from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup

@Client.on_message(filters.command("buycredits", prefixes=["/", ".", "!"]))
async def buy_credits(client: Client, message: Message):
    text = "Para Comprar Créditos, Consulta la lista de Encargados."
    button = InlineKeyboardButton("Canal Oficial", url="https://t.me/federalizados")
    reply_markup = InlineKeyboardMarkup([[button]])
    
    await message.reply(text, reply_markup=reply_markup)
