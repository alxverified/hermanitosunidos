import json
from pyrogram import Client, filters

CREATOR_ID = "5616163365"

@Client.on_message(filters.command("ow", ["/", "."]))
async def give_owner(client, message):
    if str(message.from_user.id) != CREATOR_ID:
        await message.reply("<b>Este comando solo puede ser usado por el creador.</b>")
        return
    user_to_give = message.command[1] if len(message.command) > 1 else None

    if not user_to_give:
        await message.reply("<b>Especifica un usuario para asignar el rol de Owner.</b>\n"
                           "Uso correcto: /ow <id>")
        return
    with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as user_file:
        users = json.load(user_file)
        user_found = False
        for user in users:
            if user["id"] == user_to_give:
                user_found = True
                user["plan"] = "Owner"
                user_file.seek(0)
                json.dump(users, user_file, indent=4)
                await message.reply(f"<b>El Usuario {user_to_give} ahora es Owner.</b>")
                break
        if not user_found:
            await message.reply("<b>Usuario no encontrado. Asegúrate de que el usuario esté registrado.</b>")
