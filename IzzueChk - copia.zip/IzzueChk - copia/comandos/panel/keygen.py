import random
import json
from datetime import datetime
from pyrogram import Client, filters

@Client.on_message(filters.command("key", ["/", "."]))
async def generate_key(client, message):
    user_id = str(message.from_user.id)
    try:
        with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as f:
            users = json.load(f)
            user = next((user for user in users if user['id'] == user_id), None)
    except FileNotFoundError:
        await message.reply("<b>Encontraste un bug. Notificalo a mi creador y gana recompensas.</b>")
        return
    if user and user['plan'] in ['Seller', 'Owner']:
        try:
            with open('comandos/logs/keys_log.json', 'r+', encoding='utf-8') as log_file:
                logs = json.load(log_file)
        except FileNotFoundError:
            await message.reply("<b>Encontraste un bug. Notificalo a mi creador y gana recompensas.</b>")
            return
        user_logs = logs.get(user_id, [])
        if len(user_logs) >= 20:
            await message.reply('<b>❌ Has generado demasiadas keys hoy. Podrás generar más mañana.</b>')
            return

        args = message.command[1:]
        if len(args) < 1:
            await message.reply("<b>Indica el número de días. /key <dias> <creditos> | Si no deseas añadir créditos solo indica días.</b>")
            return
        dias = args[0]
        creditos = args[1] if len(args) > 1 else '0'
        if not dias.isdigit():
            await message.reply("<b>❌ La cantidad de días debe ser un número.</b>")
            return

        if not creditos.isdigit():
            await message.reply("<b>❌ La cantidad de créditos debe ser un número.</b>")
            return
        if int(creditos) > 500:
            await message.reply("<b>❌ No puedes asignar más de 500 créditos por key.</b>")
            return
        key = f"IZZUE-KEY-{''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=13))}-CHK"
        if creditos != '0':
            key += f"-{creditos}"
        nueva_key = {
            "key": key,
            "dias": dias,
            "creditos": creditos, 
            "creador": message.from_user.username,
            "fecha_creacion": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        user_logs.append(nueva_key)
        logs[user_id] = user_logs
        with open('comandos/logs/keys_log.json', 'w', encoding='utf-8') as log_file:
            json.dump(logs, log_file, indent=4)
        await message.reply(
            f"╭────── ♡ ──────╮\n"
            f"     **KEY GENERADA** 🟢\n"
            f"╰────── ♡ ──────╯\n"
            f"—————————————————————————\n"
            f"⤏ **Key**: <code>{key}</code>\n"
            f"⤏ **Key Create By**: **{message.from_user.username}**\n"
            f"⤏ **Dias**: **{dias}**\n"
            f"⤏ **Creditos**: **{creditos}**\n"
            f"—————————————————————————\n"
            f"⤏ **Bot By**: **@ElTripleA**"
        )
        log_message = (
            f"♻ Key Generator Used.\n"
            f"🗣 User: {message.from_user.username}\n"
            f"—————————————————————————\n"
            f"🟢 Key: {key}\n"
            f"⚠ Dias: {dias}\n"
            f"⚠ Creditos: {creditos}\n"
            f"—————————————————————————\n"
            f"🏴‍☠️ Bot By: @ElTripleA"
        )
        await client.send_message(-1002473488514, log_message)
    else:
        await message.reply("<b>❌ No tienes permiso para usar este comando.</b>")