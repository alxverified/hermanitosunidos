import requests
import json
from pyrogram import Client, filters
from pyrogram.types import Message

API_URL = "http://apilayer.net/api/validate"
ACCESS_KEY = "ca42c5a821315f4ef8809c9c1a30effb"
USERS_PATH = "comandos/usuarios/users.json"

def is_user_registered(user_id):
    with open(USERS_PATH, "r") as f:
        users = json.load(f)
        return any(user['id'] == str(user_id) for user in users)

@Client.on_message(filters.command("nm", prefixes=["/", ".", "!"]))
async def validate_number(client: Client, message: Message):
    if not is_user_registered(message.from_user.id):
        await message.reply("Debes registrarte usando el comando <code>/register</code> antes de usar este comando. 🎈", reply_to_message_id=message.id)
        return

    command_parts = message.text.split()
    
    if len(command_parts) != 2:
        await message.reply("——————————————\n⌇ **COMANDO** /nm | **[伊祖-CHK]**  \n⌇ **EJEMPLO** ⇸  <code>/nm {numero}</code> \n⌇ **TOOL** ⇸ **NUMBER SEARCH** \n——————————————", reply_to_message_id=message.id)
        return
    
    number = command_parts[1]
    response = requests.get(f"{API_URL}?access_key={ACCESS_KEY}&number={number}&format=1")
    
    if response.status_code != 200:
        await message.reply("**Error al conectar con la API.** ❌", reply_to_message_id=message.id)
        return
    
    data = response.json()
    
    if not data.get("valid"):
        await message.reply("**El número proporcionado no es válido.** ❌", reply_to_message_id=message.id)
        return
    
    reply_message = (
        f"⌇ **NUMERO**: <code>{data['local_format']}</code>\n"
        f"⌇ **PAIS**: <code>{data['country_name']} - {data['country_code']}</code>\n"
        f"⌇ **V/N**: <code>{data['valid']}</code>\n"
        "——————————————\n"
        f"⌇ **PREFIJO**: <code>{data['country_prefix']}</code>\n"
        f"⌇ **TIPO**: <code>{data['line_type']}</code>\n"
        f"⌇ **EMPRESA**: <code>{data['carrier']}</code>\n"
        "——————————————\n"
        f"⌇ **PROV**: <code>{data['location']}</code>\n"
        f"⌇ **INT FOR**: <code>{data['international_format']}</code>\n"
        "——————————————\n"
        f"⌇ **BOT BY**: @ElTripleA\n"
        f"⌇ **RQ BY**: @{message.from_user.username}"
    )
    
    await message.reply(reply_message, reply_to_message_id=message.id)
