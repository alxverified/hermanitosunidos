import os
import shutil
import json
from pyrogram import Client, filters
USERS_FILE_PATH = 'comandos/usuarios/users.json'
@Client.on_message(filters.command("dlog", ["/", "."]))
async def delete_log(client, message):
    with open(USERS_FILE_PATH, 'r', encoding='utf-8') as file:
        try:
            usuarios = json.load(file)
        except json.JSONDecodeError:
            usuarios = []
    user_id = str(message.from_user.id)
    user = next((u for u in usuarios if u['id'] == user_id), None)
    if user is None or user.get('plan') != 'Owner':
        await message.reply("<b>❌ No tienes permisos para usar este comando.</b>")
        return
    pycache_dirs = [d for d in os.listdir() if d == "__pycache__"]
    for dir in pycache_dirs:
        shutil.rmtree(dir)

    await message.reply("<b>PYCache Eliminado.</b>")
