from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
import json
import pyrogram

_principio = """<b><b><a href="tg://resolve?domain=ElTripleA">List comand ☁️</a></b>

⤷ Gates                           <code>6</code>
⤷ Status                          <code>ON ✅</code>
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ Tools                           <code>2</code>
⤷ Status                          <code>ON ✅</code></b>
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
</b>
"""

_principiobotons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Gates",
                            callback_data="gates"
                        ),
                        InlineKeyboardButton(
                            "Tools",
                            callback_data="tools"
                        ),
                    ],
                    [
                        InlineKeyboardButton( 
                            "Canal",
                            url="https://t.me/federalizados"),
                        InlineKeyboardButton( 
                            "Creador",
                            url="https://t.me/ElTripleA"
                        ),
                    ],
                ]
            )

_back_close_buttons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton("Back", callback_data="back"),
                        InlineKeyboardButton("Close", callback_data="close"),
                    ],
                ]
            )

@Client.on_message(filters.command("cmds", ["/", "."]))
async def cmds(client, message):
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)
        user = next((u for u in users if str(u['id']) == str(message.from_user.id)), None)
        if user:
            await client.send_message(message.chat.id, _principio, reply_markup=_principiobotons, reply_to_message_id=message.id)
        else:
            await message.reply("<b>❌ Usuario no registrado. Usa /register para registrarte.</b>")

@Client.on_callback_query(filters.regex("gates"))
async def on_gates(client: Client, callback_query: CallbackQuery):
    _Call_Gateways = """<b><b><a href="tg://resolve?domain=ElTripleA">Gates | Gateways ♻</a></b>

⤷ **Hylux** | **Mobbex** <code>[ -1 Credito ]</code>
⤷ **Usar** <code>/mb card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ **Tyler** | **Mubi** <code>[ -1 Credito ]</code>
⤷ **Usar** <code>/mi card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ **July** | **Mercado Pago** <code>[ -1 Credito ]</code>
⤷ **Usar** <code>/mp card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ **Frederic** | **PayU** <code>[ -1 Credito ]</code>
⤷ **Usar** <code>/pyu card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ **Pijudo** | **PagoFacil** <code>[ -1 Credito ]</code>
⤷ **Usar** <code>/pf card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ **Enzo** | **RapiPago** <code>[ -1 Credito ]</code>
⤷ **Usa**r <code>/rp card</code> **On [ ✅ ]**
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
</b>"""
    await callback_query.message.edit_text(_Call_Gateways, reply_markup=_back_close_buttons)

@Client.on_callback_query(filters.regex("tools"))
async def on_tools(client: Client, callback_query: CallbackQuery):
    _Call_Tools = """<b><b> <b><a href="tg://resolve?domain=federalizados">Herramientas | Tools 🔮</a></b>

⤷ Buscador De Numero - <code>[ FREE ]</code>
⤷ Usar <code>/nm numero</code>
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
⤷ Bin - <code>[ FREE ]</code>
⤷ Usar <code>/bin 455599</code>
━━━━━━ ◦ 🇦🇷 ◦ ━━━━━━
    </b>"""
    await callback_query.message.edit_text(_Call_Tools, reply_markup=_back_close_buttons)

@Client.on_callback_query(filters.regex("back"))
async def on_back(client: Client, callback_query: CallbackQuery):
    await callback_query.message.edit_text(_principio, reply_markup=_principiobotons)

@Client.on_callback_query(filters.regex("close"))
async def on_close(client: Client, callback_query: CallbackQuery):
    try:
        await callback_query.message.delete()
        await client.send_message(callback_query.message.chat.id, "<b>Menu Closed.</b>")
    except Exception as e:
        print(f"Error: {e}")
