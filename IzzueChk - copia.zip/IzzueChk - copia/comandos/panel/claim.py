import json
from datetime import datetime
from pyrogram import Client, filters

@Client.on_message(filters.command("claim", ["/", "."]))
async def claim_key(client, message):
    user_id = str(message.from_user.id)
    args = message.command[1:]
    if len(args) < 1:
        await message.reply("<b>Especifica la key que deseas reclamar.</b>")
        return
    key_to_claim = args[0]
    try:
        with open('comandos/logs/keys_log.json', 'r+', encoding='utf-8') as log_file:
            logs = json.load(log_file)
    except FileNotFoundError:
        await message.reply("<b>Encontraste un bug. | Avisale a el Creador y gana una recompensa.</b>")
        return
    key_found = None
    user_found = None
    for user, keys in logs.items():
        for key in keys:
            if key['key'] == key_to_claim:
                key_found = key
                user_found = user
                break
        if key_found:
            break
    if not key_found:
        await message.reply("<b>❌ Key no encontrada o ya ha sido reclamada.</b>")
        return
    logs[user_found] = [key for key in logs[user_found] if key['key'] != key_to_claim]
    with open('comandos/logs/keys_log.json', 'w', encoding='utf-8') as log_file:
        json.dump(logs, log_file, indent=4)
    try:
        with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as user_file:
            users = json.load(user_file)
    except FileNotFoundError:
        await message.reply("<b>Error: El archivo de usuarios no existe.</b>")
        return
    user = next((u for u in users if u['id'] == user_id), None)
    if user:
        if user['plan'] == 'Free User': 
            user['plan'] = 'Premium'
        user['creditos'] = str(int(user.get('creditos', 0)) + int(key_found.get('creditos', 0)))
        user['dias'] = str(int(user.get('dias', 0)) + int(key_found.get('dias', 0)))
        with open('comandos/usuarios/users.json', 'w', encoding='utf-8') as user_file:
            json.dump(users, user_file, indent=4)
    log_message = (
        f"♻ | Key Reclamada: {key_to_claim}\n"
        f"🗣 | Reclamada por: {message.from_user.username}\n"
        f"———————————————\n"
        f"〻 | Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"〻 | Dias: {key_found['dias']}\n"
        f"〻 | Creditos: {key_found.get('creditos', 0)}\n"
        f"———————————————\n"
        f"〻 | Usuario que la creó: {key_found['creador']}"
    )
    await client.send_message(-1002473488514, log_message)
    creditos = key_found.get('creditos', 0)
    user_message = (
        f"🎁 Key Reclamada Exitosamente 🎁\n"
        f"———————————————\n"
        f"♻ Key : {key_to_claim}\n"
        f"〻 Dias: {key_found['dias']}\n"
        f"〻 Creditos: {creditos}\n"
        f"———————————————\n"
        f"〻 | Bot By: @ElTripleA\n"
        f"〻 | User: {message.from_user.username}"
    )
    await message.reply(user_message)
