import json
import os
import sys
from pyrogram import Client, filters

@Client.on_message(filters.command("rs", ["/", "."]))
async def reset_system(client, message):
    user_id = str(message.from_user.id)
    with open('comandos/usuarios/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)
        user = next((user for user in users if user['id'] == user_id), None)
    if user and user['plan'] == 'Owner':
        await message.reply("<b>El sistema ha sido reseteado y el bot se está reiniciando...</b>")
        try:
            os.execv(sys.executable, ['python'] + sys.argv)
        except Exception as e:
            await message.reply(f"<b>Error al intentar reiniciar el bot: {e}</b>")
    else:
        await message.reply("<b>Solo los Owners pueden ejecutar este comando.</b>")