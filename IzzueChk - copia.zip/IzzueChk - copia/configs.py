from os import path, getenv

class Config:
    API_ID = int(getenv('API_ID','26829769'))
    API_HASH = getenv('API_HASH','48f0b6400cff661673111f20860ad1e9')
    BOT_TOKEN = getenv('BOT_TOKEN','7958664178:AAFYQBsP9jRwA-N06uBgueeWhdNygyd84Ls')

config = Config()
