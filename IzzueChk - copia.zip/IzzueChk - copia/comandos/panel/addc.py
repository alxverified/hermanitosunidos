import json
import os
from pyrogram import Client, filters
from pyrogram.types import Message

USERS_PATH = 'comandos/usuarios/users.json'

def get_user_plan(user_id):
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
            for user in users:
                if user['id'] == str(user_id):
                    return user['plan']
    return None
@Client.on_message(filters.command("addc", prefixes=["/", ".", "!"]))
async def add_credits(client: Client, message: Message):
    user_id = message.from_user.id
    user_plan = get_user_plan(user_id)
    if user_plan not in ["Owner", "Seller"]:
        await message.reply("No tienes permiso para usar este comando.")
        return
    command_parts = message.text.split()
    if len(command_parts) != 3:
        await message.reply("Debes indicar el ID del usuario y la cantidad de créditos. Formato correcto: `/addc <id> <cantidad>`.")
        return
    try:
        target_id = int(command_parts[1]) 
        cantidad = int(command_parts[2])
    except ValueError:
        await message.reply("El ID y la cantidad deben ser números.")
        return
    if cantidad > 500:
        await message.reply("No se pueden añadir más de 500 créditos en una sola operación.")
        return
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
            user_found = False
            for user in users:
                if user['id'] == str(target_id):
                    user['creditos'] = str(int(user['creditos']) + cantidad)
                    user_found = True
                    break
            if user_found:
                with open(USERS_PATH, 'w') as users_file:
                    json.dump(users, users_file, indent=4)
                await message.reply(f"Se han agregado {cantidad} créditos al usuario con ID {target_id}.")
            else:
                await message.reply(f"El usuario con ID {target_id} no está registrado. Debe registrarse usando el comando /register.")
    else:
        await message.reply("No se pudo encontrar el archivo de usuarios.")
