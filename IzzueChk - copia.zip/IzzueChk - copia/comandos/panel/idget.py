import json
from pyrogram import Client, filters

@Client.on_message(filters.command("id", ["/", "."]))
async def get_chat_id(client, message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    await message.reply(
        f"<b>Chat ID:</b> <code>{chat_id}</code>\n"
        f"<b>You ID:</b> <code>{user_id}</code>"
    )
