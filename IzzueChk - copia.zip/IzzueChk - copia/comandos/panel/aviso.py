import json
import os
from pyrogram import Client, filters
from pyrogram.types import Message

USERS_PATH = 'comandos/usuarios/users.json'

@Client.on_message(filters.command("aviso", prefixes=["/", ".", "!"]) & filters.user(5616163365))
async def send_notice(client: Client, message: Message):
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) != 2:
        await message.reply("Debes proporcionar el texto del aviso. Formato correcto: `/aviso {texto}`.")
        return

    texto = command_parts[1]
    if os.path.exists(USERS_PATH):
        with open(USERS_PATH, 'r') as users_file:
            users = json.load(users_file)
            total_enviados = 0
            total_no_enviados = 0
            
            for user in users:
                try:
                    await client.send_message(chat_id=user['id'], text=texto)
                    total_enviados += 1
                except Exception as e:
                    total_no_enviados += 1
            
            await message.reply(f"El aviso ha sido enviado correctamente a {total_enviados} usuarios.\nNo se pudo enviar a {total_no_enviados} usuarios.")
    else:
        await message.reply("No se pudo encontrar el archivo de usuarios.")