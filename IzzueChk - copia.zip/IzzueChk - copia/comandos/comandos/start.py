import json
from datetime import datetime
from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
import asyncio
_start_template = """
** 〻 [𝙸𝚣𝚣𝚞𝚎 𝙲𝚑𝚔](https://t.me/ElTripleA)〻**
═══════ [ 🇦🇷 ] ═══════ 
⤷ **Hora:**              **{hora}**
⤷ **Tiempo:**            **{estado}**
⤷ **ID:**                **{user_id}**
⤷ **User:**              **{user}**
⤷ **Version:**           **1.0**
═══════ [ 🇦🇷 ] ═══════ 
⤷ **Fecha:**             **{tiempo}**
⤷ **Create:**           [ 𝙵𝚎𝚍𝚎𝚛𝚊𝚕𝚒𝚣𝚊𝚍𝚘𝚜 ](https://t.me/Federalizados)
"""
def get_part_of_day():
    hora_actual = datetime.now().hour
    if 5 <= hora_actual < 12:
        return "Buenos días"
    elif 12 <= hora_actual < 18:
        return "Buenas tardes"
    else:
        return "Buenas noches"
def make_ordinal(n):
    n = int(n)
    if 10 <= n % 100 <= 20:
        suffix = 'th'
    else:
        suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
    return str(n) + suffix
@Client.on_message(filters.command("start", ["/", "."]))
async def start(client, message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    m = await message.reply_sticker("CAACAgUAAxkBAAIFNGJSlfOErbkSeLt9SnOniU-58UUBAAKaAAPIlGQULGXh4VzvJWoeBA")
    await asyncio.sleep(1.5)
    await m.delete()
    with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as archivo:
        try:
            usuarios = json.load(archivo)
        except json.JSONDecodeError:
            usuarios = []  
    user_id = str(message.from_user.id)
    registrado = any(user['id'] == user_id for user in usuarios)
    if registrado:
        tiempo = datetime.now().strftime("%d %m %Y")
        hora = datetime.now().strftime("%H:%M %p")
        day = make_ordinal(datetime.now().strftime("%d"))
        mes = datetime.now().strftime("%m")
        year = datetime.now().strftime("%Y")
        text = _start_template.format(
            user=message.from_user.first_name,
            user_id=user_id,
            day=day,
            mes=mes,
            year=year,
            hora=hora,
            tiempo=tiempo,
            estado=get_part_of_day()
        )
        await client.send_photo(
            message.chat.id,
            "https://imgur.com/a/iYY2J3x",
            caption=text,
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton("𝙲𝚊𝚗𝚊𝚕 𝙾𝚏𝚒𝚌𝚒𝚊𝚕", url="https://t.me/federalizados")
                ]]
            )
        )
    else:
        await message.reply("**￤ Registrese con el comando `/register`**")
