import json
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

@Client.on_message(filters.command("register", ["/", "."]))
async def register_user(client, message):
    user_id = str(message.from_user.id)
    username = f"@{message.from_user.username}" if message.from_user.username else "SinUsername"
    chat_id = str(message.chat.id)
    fecha_registro = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    nuevo_usuario = {
        "id": user_id,
        "username": username,
        "fecha_registro": fecha_registro,
        "chat": chat_id,
        "creditos": "20",
        "dias": "0",
        "plan": "Free User"
    }
    with open('comandos/usuarios/users.json', 'r+', encoding='utf-8') as archivo:
        try:
            usuarios = json.load(archivo)
        except json.JSONDecodeError:
            usuarios = []
        if any(user['id'] == user_id for user in usuarios):
            await message.reply("Ya estás registrado. ❌")
        else:
            usuarios.append(nuevo_usuario)
            archivo.seek(0)
            json.dump(usuarios, archivo, indent=4)
            formatted_message = (
                "┌──────────────────┐\n"
                "         𝐑𝐄𝐆𝐈𝐒𝐓𝐑𝐎 𝐄𝐗𝐈𝐓𝐎𝐒𝐎\n"
                "└──────────────────┘\n"
                f"\n"
                f"↳ **Usuario**: {username}\n"
                f"↳ **ID**: {user_id}\n"
                f"↳ **Fecha**: {fecha_registro}\n"
                f"**———————————————**\n"
                f"↳ **Plan**: **Free User**\n"
                f"↳ **Creditos**: **20**\n"
                f"↳ **Bot By**: **@ElTripleA**"
            )
            await client.send_photo(
                chat_id=message.chat.id,
                photo="https://imgur.com/a/iYY2J3x",
                caption=formatted_message,
                reply_markup=InlineKeyboardMarkup(
                    [[
                        InlineKeyboardButton("𝙲𝚊𝚗𝚊𝚕 𝙾𝚏𝚒𝚌𝚒𝚊𝚕", url="https://t.me/federalizados")
                    ]]
                )
            )
